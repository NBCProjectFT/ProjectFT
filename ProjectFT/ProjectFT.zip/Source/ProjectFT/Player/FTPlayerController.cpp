// Fill out your copyright notice in the Description page of Project Settings.

#include "FTPlayerController.h"

#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "InputMappingContext.h"

#include "ProjectFT/Core/FTLogChannels.h"
#include "ProjectFT/AbilitySystem/FTAbilityTags.h"
#include "ProjectFT/Components/FTQuickSlotComponent.h"
#include "ProjectFT/Interface/FTInputInterface.h"

void AFTPlayerController::BeginPlay()
{
	Super::BeginPlay();

	ULocalPlayer* LocalPlayer = GetLocalPlayer();
	if (!LocalPlayer)
	{
		return;
	}

	UEnhancedInputLocalPlayerSubsystem* Subsystem = LocalPlayer->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>();
	if (!Subsystem || !DefaultMappingContext)
	{
		return;
	}

	if (bClearMappingsBeforeAdd)
	{
		Subsystem->ClearAllMappings();
	}

	Subsystem->AddMappingContext(DefaultMappingContext, 0);
}

void AFTPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	UEnhancedInputComponent* EnhancedInput = Cast<UEnhancedInputComponent>(InputComponent);
	if (!EnhancedInput)
	{
		return;
	}

	if (MoveAction)
	{
		EnhancedInput->BindAction(MoveAction, ETriggerEvent::Triggered, this, &AFTPlayerController::OnMoveTriggered);
	}

	if (LookAction)
	{
		EnhancedInput->BindAction(LookAction, ETriggerEvent::Triggered, this, &AFTPlayerController::OnLookTriggered);
	}

	if (JumpAction)
	{
		EnhancedInput->BindAction(JumpAction, ETriggerEvent::Started, this, &AFTPlayerController::OnJumpStarted);
		EnhancedInput->BindAction(JumpAction, ETriggerEvent::Completed, this, &AFTPlayerController::OnJumpCompleted);
	}

	if (SprintAction)
	{
		EnhancedInput->BindAction(SprintAction, ETriggerEvent::Started, this, &AFTPlayerController::OnSprintStarted);
		EnhancedInput->BindAction(SprintAction, ETriggerEvent::Completed, this, &AFTPlayerController::OnSprintCompleted);
	}

	if (CrouchAction)
	{
		EnhancedInput->BindAction(CrouchAction, ETriggerEvent::Started, this, &AFTPlayerController::OnCrouchStarted);
		EnhancedInput->BindAction(CrouchAction, ETriggerEvent::Completed, this, &AFTPlayerController::OnCrouchCompleted);
	}

	if (InteractAction)
	{
		EnhancedInput->BindAction(InteractAction, ETriggerEvent::Started, this, &AFTPlayerController::OnInteractStarted);
		EnhancedInput->BindAction(InteractAction, ETriggerEvent::Completed, this, &AFTPlayerController::OnInteractCompleted);
	}

	if (SkillCheckAction)
	{
		EnhancedInput->BindAction(SkillCheckAction, ETriggerEvent::Started, this, &AFTPlayerController::OnSkillCheckStarted);
	}

	if (UseItemAction)
	{
		EnhancedInput->BindAction(UseItemAction, ETriggerEvent::Started, this, &AFTPlayerController::OnUseItemStarted);
	}

	if (QuickSlot1Action)
	{
		EnhancedInput->BindAction(QuickSlot1Action, ETriggerEvent::Started, this, &AFTPlayerController::OnQuickSlot1Started);
	}

	if (QuickSlot2Action)
	{
		EnhancedInput->BindAction(QuickSlot2Action, ETriggerEvent::Started, this, &AFTPlayerController::OnQuickSlot2Started);
	}

	if (QuickSlot3Action)
	{
		EnhancedInput->BindAction(QuickSlot3Action, ETriggerEvent::Started, this, &AFTPlayerController::OnQuickSlot3Started);
	}

	if (QuickSlot4Action)
	{
		EnhancedInput->BindAction(QuickSlot4Action, ETriggerEvent::Started, this, &AFTPlayerController::OnQuickSlot4Started);
	}
}

void AFTPlayerController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	CachedInputPawn = InPawn;
	CachedLocomotionInput = Cast<IFTInputInterface>(InPawn);

	if (!CachedLocomotionInput)
	{
		UE_LOG(LogFTPlayer, Warning,
			TEXT("Possessed pawn '%s' does not implement IFTInputInterface; locomotion input will be ignored."),
			*GetNameSafe(InPawn));
	}
}

void AFTPlayerController::OnUnPossess()
{
	CachedInputPawn = nullptr;
	CachedLocomotionInput = nullptr;

	Super::OnUnPossess();
}

void AFTPlayerController::OnMoveTriggered(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleMoveInput(Value.Get<FVector2D>());
	}
}

void AFTPlayerController::OnLookTriggered(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleLookInput(Value.Get<FVector2D>());
	}
}

void AFTPlayerController::OnJumpStarted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleJumpPressed();
	}
}

void AFTPlayerController::OnJumpCompleted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleJumpReleased();
	}
}

void AFTPlayerController::OnSprintStarted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleSprintPressed();
	}
}

void AFTPlayerController::OnSprintCompleted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleSprintReleased();
	}
}

void AFTPlayerController::OnCrouchStarted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleCrouchPressed();
	}
}

void AFTPlayerController::OnCrouchCompleted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleCrouchReleased();
	}
}

void AFTPlayerController::OnInteractStarted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleInteractPressed();
	}
}

void AFTPlayerController::OnInteractCompleted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleInteractReleased();
	}
}

void AFTPlayerController::OnSkillCheckStarted(const FInputActionValue& Value)
{
	if (CachedLocomotionInput)
	{
		CachedLocomotionInput->HandleSkillCheckPressed();
	}
}

void AFTPlayerController::OnUseItemStarted(const FInputActionValue& Value)
{
	if (UFTQuickSlotComponent* QuickSlot = FindQuickSlotComponent())
	{
		QuickSlot->HandleInputTag(TAG_FT_Input_Item_Primary);
	}
}

void AFTPlayerController::OnQuickSlot1Started(const FInputActionValue& Value)
{
	if (UFTQuickSlotComponent* QuickSlot = FindQuickSlotComponent())
	{
		QuickSlot->HandleInputTag(TAG_FT_Input_QuickSlot_1);
	}
}

void AFTPlayerController::OnQuickSlot2Started(const FInputActionValue& Value)
{
	if (UFTQuickSlotComponent* QuickSlot = FindQuickSlotComponent())
	{
		QuickSlot->HandleInputTag(TAG_FT_Input_QuickSlot_2);
	}
}

void AFTPlayerController::OnQuickSlot3Started(const FInputActionValue& Value)
{
	if (UFTQuickSlotComponent* QuickSlot = FindQuickSlotComponent())
	{
		QuickSlot->HandleInputTag(TAG_FT_Input_QuickSlot_3);
	}
}

void AFTPlayerController::OnQuickSlot4Started(const FInputActionValue& Value)
{
	if (UFTQuickSlotComponent* QuickSlot = FindQuickSlotComponent())
	{
		QuickSlot->HandleInputTag(TAG_FT_Input_QuickSlot_4);
	}
}

UFTQuickSlotComponent* AFTPlayerController::FindQuickSlotComponent() const
{
	const APawn* ControlledPawn = GetPawn();
	return ControlledPawn
		? ControlledPawn->FindComponentByClass<UFTQuickSlotComponent>()
		: nullptr;
}
